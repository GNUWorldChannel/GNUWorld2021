-- Use this file to populate the 'languages' table.
--
-- $Id: chanfix.languages.sql,v 1.4 2006/12/09 00:29:20 buzlip01 Exp $

DELETE FROM languages;
COPY "languages" FROM stdin;
1	EN	English	31337	0
\.
